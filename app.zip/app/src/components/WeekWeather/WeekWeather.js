import React from "react";
import "./week.css";

export default function WeekWeather() {
  return (
    <div className="grid-2 cont-block">
      <div className="padd-block">
        <h3>Haftalik ob-havo ma'lumoti</h3>
      </div>

      <table className="weather-table">
        <tbody>
          <tr>
            <th className="weather-row-day">Kun</th>
            <th className="weather-row-day-short">Kun</th>
            <th colSpan="2">Harorat</th>
            <th className="weather-row-desc">Tavsif</th>
            <th className="weather-row-pop">Yog'ingarchilik</th>
          </tr>

          <tr>
            <td className="weather-row-day  weekend ">
              <strong>Ertaga</strong>
              <div>24 iyul</div>
            </td>
            <td className="weather-row-day-short  weekend ">
              <strong>YAK</strong>
              <div>24 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/clear.png"
                  title="Ochiq havo"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+44°</span>
              <span className="forecast-night">+28°</span>
            </td>
            <td className="weather-row-desc">ochiq havo</td>
            <td className="weather-row-pop">0%</td>
          </tr>
          <tr>
            <td className="weather-row-day ">
              <strong>Dushanba</strong>
              <div>25 iyul</div>
            </td>
            <td className="weather-row-day-short ">
              <strong>DU</strong>
              <div>25 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/clear.png"
                  title="Ochiq havo"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+45°</span>
              <span className="forecast-night">+29°</span>
            </td>
            <td className="weather-row-desc">ochiq havo</td>
            <td className="weather-row-pop">0%</td>
          </tr>
          <tr>
            <td className="weather-row-day ">
              <strong>Seshanba</strong>
              <div>26 iyul</div>
            </td>
            <td className="weather-row-day-short ">
              <strong>SE</strong>
              <div>26 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/clear.png"
                  title="Ochiq havo"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+45°</span>
              <span className="forecast-night">+30°</span>
            </td>
            <td className="weather-row-desc">ochiq havo</td>
            <td className="weather-row-pop">0%</td>
          </tr>
          <tr>
            <td className="weather-row-day ">
              <strong>Chorshanba</strong>
              <div>27 iyul</div>
            </td>
            <td className="weather-row-day-short ">
              <strong>CHOR</strong>
              <div>27 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/clear.png"
                  title="Ochiq havo"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+41°</span>
              <span className="forecast-night">+28°</span>
            </td>
            <td className="weather-row-desc">ochiq havo</td>
            <td className="weather-row-pop">0%</td>
          </tr>
          <tr>
            <td className="weather-row-day ">
              <strong>Payshanba</strong>
              <div>28 iyul</div>
            </td>
            <td className="weather-row-day-short ">
              <strong>PA</strong>
              <div>28 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/clear.png"
                  title="Ochiq havo"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+42°</span>
              <span className="forecast-night">+28°</span>
            </td>
            <td className="weather-row-desc">ochiq havo</td>
            <td className="weather-row-pop">0%</td>
          </tr>
          <tr>
            <td className="weather-row-day ">
              <strong>Juma</strong>
              <div>29 iyul</div>
            </td>
            <td className="weather-row-day-short ">
              <strong>JUM</strong>
              <div>29 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/clear.png"
                  title="Ochiq havo"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+39°</span>
              <span className="forecast-night">+25°</span>
            </td>
            <td className="weather-row-desc">ochiq havo</td>
            <td className="weather-row-pop">0%</td>
          </tr>
          <tr>
            <td className="weather-row-day  weekend ">
              <strong>Shanba</strong>
              <div>30 iyul</div>
            </td>
            <td className="weather-row-day-short  weekend ">
              <strong>SHA</strong>
              <div>30 iyul</div>
            </td>
            <td className="weather-row-forecast-icon">
              <span title="#">
                <img
                  src="https://obhavo.uz/images/icons/rain.png"
                  title="Yomg'ir"
                />
              </span>
            </td>
            <td className="weather-row-forecast">
              <span className="forecast-day">+37°</span>
              <span className="forecast-night">+24°</span>
            </td>
            <td className="weather-row-desc">yomg'ir</td>
            <td className="weather-row-pop">30%</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
