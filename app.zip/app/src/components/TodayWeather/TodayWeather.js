import React, { useState } from "react";
import "./today.css";

export default function TodayWeather() {
  const apiKey = "9adddd3995c8b831d0c5d26a434a1aab";
  const [weatherData, setWeatherData] = useState([{}]);
  // const [city, setCity] = useState("");
  const dataMonth = new Date().getMonth();
  const monthArr = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  let month = monthArr[dataMonth];
  window.onload = () => {
    getWeather();
  };
  const getWeather = () => {
    // if (event.key === "Enter") {
    navigator.geolocation.getCurrentPosition((success) => {
      let { latitude, longitude } = success.coords;

      fetch(
        `https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=hourly,minutely&units=metric&appid=${apiKey}`
      )
        .then((res) => res.json())
        .then((data) => {
          showWeatherData(data);
        });
    });
    // }
  };
  const showWeatherData = (data) => {
    console.log(data);
    console.log(data.timezone);
    console.log("Day 0", data.daily[0]);
  };

  let directions = [
    "North",
    "North-East",
    "East",
    "South-East",
    "South",
    "South-West",
    "West",
    "North-West",
  ];

  function getDirection(heading) {
    var index = Math.round(heading / 8 / 5, 625);
    return directions[index];
  }

  return (
    <>
      <div className="padd-block">
        {showWeatherData}
        <div className="grid-1 cont-block">
          <div className="padd-block">
            <h2>{weatherData.timezone}</h2>
            <div className="current-day">
              Today, {new Date().getDate()} {month}
            </div>

            <div className="current-forecast">
              <span>
                <img src="https://obhavo.uz/images/icons/clear.png" />
              </span>
              <span>
                <strong>
                  +
                  {/* {Math.floor(
                    (Math.round(weatherData.main.temp_max) - 32) * (5 / 9)
                  )} */}
                  °C
                </strong>
              </span>
              <span>
                +
                {/* {Math.floor(
                  (Math.round(weatherData.main.temp_min) - 32) * (5 / 9)
                )} */}
                °C
              </span>
            </div>

            <div className="current-forecast-desc">
              {/* {weatherData.weather[0].main} */}
            </div>

            <div className="current-forecast-details">
              <div className="col-1">
                <p>
                  Feels Like:+
                  {/* {Math.floor(
                    (Math.round(weatherData.main.feels_like) - 32) * (5 / 9)
                  )} */}
                  °C
                </p>
                <p>
                  Humidity:
                  {/* {weatherData.main.humidity} */}%
                </p>
                <p>
                  Wind:
                  {/* {getDirection(weatherData.wind.deg)},{" "}
                  {Math.floor(weatherData.wind.speed)} */}
                  km/h
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
